# Glass UI mod for VLC Android

Dark gradient + glassmorphism (translucent white layers, hairline borders, rounded cards), VLC orange kept as accent.

## What changed
- `application/resources/.../values/colors_glass.xml`  new palette
- `application/resources/.../drawable/`  glass_window_background, bottom_navigation_background_glass, glass_mini_player,
  video_grid_card_background_glass, video_list_background_glass, round_background_glass
- `application/vlc-android/res/values/styles.xml`  `Theme.VLC.Apearance.Black` now points to the glass drawables
  (Material TV theme keeps the old flat look)
- `application/vlc-android/src/.../gui/helpers/UiTools.kt`  default theme = Dark ("2"); the dark branch now paints the
  gradient as window background instead of a flat colour
- `.github/workflows/build.yml`  GitHub Actions build (debug APK on every push, signed release on `v*` tags)

## Not included
Real backdrop blur. Glass here is translucency + gradient (works on every Android version). The light theme is unchanged.

## Revert
Restore the 10 attributes in `Theme.VLC.Apearance.Black` (see the TV override block in styles.xml for the original values)
and the two edits in UiTools.kt.
